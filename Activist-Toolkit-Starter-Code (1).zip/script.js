/* .js files add interaction to your website */

var factList = [
"It takes a 15-year-old tree to produce 700 grocery bags.",
"An average American family can use up to 260 gallons of water at home per day.",
"According to sustainability facts, energy is the number one contributor to climate change, accounting for around 60% of total global greenhouse gas emissions.",
"25% of the bottled water you buy is really municipal tap water.",
"A modern glass bottle takes 4000 years or more to decompose.",
"In the last 170 years, we added 2.4 trillion tons of Carbon Dioxide into our atmosphere. Half of this was added in the last 35 to 50 years.",
"Due to uneven distribution patterns, minority and low income communities have far less access to green spaces than white, affluent communities and have limited resources to maintain the green spaces they do have.",
"In 2015, about 54.4 million people (17.7% of total U.S. population) had low access to a supermarket due to limited transportation and uneven distribution of supermarkets.",
"Rainforests are being cut down at the rate of 100 acres per minute.",
"Americans use over 80,000,000,000 aluminum soda cans every year and if we recycle one soda can we can save enough energy to power a TV for 3 hours."
];

var fact=document.getElementById("fact");
var gen = document.getElementById("gen");
var count=0;


if(gen){
gen.addEventListener("click", displayFact);
}

function displayFact(){
fact.innerHTML = factList[count];
count++;

if(count ==  factList.length){
count=0;
  }

}